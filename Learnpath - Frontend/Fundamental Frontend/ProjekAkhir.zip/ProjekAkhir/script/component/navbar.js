class Navbar extends HTMLElement
{
    constructor()
    {
        super();
    }

    showLayout()
    {
        this.innerHTML = `  <nav class="navbar navbar-light bg-primary">
                                <div class="container-fluid">
                                    <div class="col-md-2 col-sm-3 col-xs-3">
                                        <a class="navbar-brand text-white" href="https://makinrajin.com">
                                            <img src="https://makinrajin.com/wp-content/uploads/2019/02/Logo-Putih.png" class="img-fluid">
                                        </a>
                                    </div>
                                </div>
                            </nav>`;
    }

    connectedCallback()
    {
        this.showLayout();
    }
}

customElements.define("nav-bar", Navbar);