class ArticleList extends HTMLElement
{
    constructor()
    {
        super();
    }

    set articles(articles)
    {
        this.posts = articles;
        this.showLayout();
    }

    showLayout()
    {
        if(this.posts)
        {
            this.innerHTML = '';
            this.posts.forEach((post) => {
                console.log(post);
                this.innerHTML += `  <div class="container-fluid my-4">
                                        <div class="col-md-8">
                                            <center><img src="${post.jetpack_featured_media_url}" class="img-fluid"></center>
                                        </div>
                                        <div class="col-md-8 p-md-5 p-4 shadow bg-white">
                                            <h2>${post.title.rendered}</h2>
                                            <p>${post.excerpt.rendered}</p>
                                            <a href="${post.link}" class="btn btn-primary right">Read More</a>
                                        </div>
                                    </div>
                                `;
            })
        }

        else
        {
            this.innerHTML = `<style>
                                .title-before
                                {
                                    background-color: #aaa;
                                    height: 10px;
                                    border-radius: 5px;
                                }

                                .description-before
                                {
                                    background-color: #ccc;
                                    height: 10px;
                                    border-radius: 5px;
                                }

                                .image-before
                                {
                                    background-color: #aaa;
                                    height: 300px;
                                }
                            `
            for(let i=0; i<4; i++)
            {
                this.innerHTML += `  <div class="container-fluid mt-4">
                                        <div class="col-md-8">
                                            <div class="image-before"></div>
                                        </div>
                                        <div class="col-md-8 p-5 shadow bg-white">
                                            <div class="col-md-5">
                                                <div class="title-before mb-5"></div>
                                            </div>
                                            <div class="description-before mb-3"></div>
                                            <div class="description-before mb-3"></div>
                                            <div class="description-before mb-3"></div>
                                            <div class="description-before mb-3"></div>
                                        </div>
                                    </div>
                                `;  
            }
        }
    }

    
    connectedCallback()
    {
        this.showLayout();
    }
}

customElements.define("article-list", ArticleList);