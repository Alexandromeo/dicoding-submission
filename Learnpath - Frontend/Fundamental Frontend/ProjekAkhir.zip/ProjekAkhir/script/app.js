import $ from "jquery";
import 'bootstrap/dist/css/bootstrap.min.css';
import main from './data/main.js';
import './component/navbar.js';
import './component/article-list.js';
document.addEventListener("DOMContentLoaded", main)