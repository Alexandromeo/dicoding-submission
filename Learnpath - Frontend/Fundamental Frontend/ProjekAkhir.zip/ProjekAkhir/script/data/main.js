import Source from './source.js';
const main = () => {
    let articleList = document.querySelector("article-list");
    const setPost = (data) => {
        articleList.articles = data;
    }

    const renderError = (message) => {
        console.log(message)
    }

    Source.searchArticle().then(setPost).catch(renderError);
}

export default main