class Source
{
    static searchArticle()
    {
        return new Promise((resolve, reject) => {
            fetch('https://makinrajin.com/blog/wp-json/wp/v2/posts').then((response) => {
                return response.json();
            }).then((articles) => {
                resolve(articles);
            }).catch(`Articles not found`);
        })
    }
}


export default Source