const CACHE_NAME = "bolibal";
let urlsToCache = [
  "/",
  "/manifest.json",
  "/nav.html",
  "/index.html",
  "/pages/home.html",
  "/css/materialize.min.css",
  "/css/style.css",
  "/js/component/navbar.js",
  "/js/api.js",
  "/js/db.js",
  "/js/fcm.js",
  "/js/idb.js",
  "/js/main.js",
  "/js/materialize.min.js",
  "/js/nav.js",
  "/js/push-notif.js",
  "/js/sw.js",
  "/img/logo-512.png",
  "/img/logo-192.png",
];

self.addEventListener('push', (event) => {
  var body;
  if (event.data) {
    body = event.data.text();
  } else {
    body = 'Push message no payload';
  }
  var options = {
    body: body,
    icon: 'img/notification.png',
    vibrate: [100, 50, 100],
    data: {
      dateOfArrival: Date.now(),
      primaryKey: 1
    }
  };
  event.waitUntil(
    self.registration.showNotification('Push Notification', options)
  );
});

const addCache = (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(urlsToCache);
    })
  );
}

const fetchCache = (event) => {
  event.respondWith(
    caches.match(event.request, {cacheName:CACHE_NAME})
    .then(function(response) {
      if (response) {
        return response;
      }
      const fetchRequest = event.request.clone();
      return fetch(fetchRequest).then(
        function(response) {
          if(!response || response.status !== 200) {
            return response;
          }
          const  responseToCache = response.clone();
          caches.open(CACHE_NAME)
          .then(function(cache) {
            cache.put(event.request, responseToCache);
          });
          return response;
        }
      );
    })
  );
}

const replaceCache = (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName != CACHE_NAME) {
            console.log(`ServiceWorker: cache  ${cacheName} dihapus`);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
}


self.addEventListener("install", (event) => { addCache(event) });
self.addEventListener("fetch", (event) => { fetchCache(event) });
self.addEventListener("activate", (event) => { replaceCache(event) });