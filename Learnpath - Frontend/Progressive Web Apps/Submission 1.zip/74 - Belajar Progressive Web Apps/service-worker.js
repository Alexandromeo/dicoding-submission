const CACHE_NAME = "pwa";
var urlsToCache = [
  "/",
  "/nav.html",
  "/index.html",
  "/pages/home.html",
  "/pages/bawahlaut.html",
  "/pages/gunung.html",
  "/pages/pantai.html",
  "/css/materialize.min.css",
  "/css/style.css",
  "/js/materialize.min.js",
  "/js/nav.js",
  "icon/beach.svg",
  "icon/home.svg",
  "icon/mountain.svg",
  "icon/snorkling.svg",
  "/img/logo.png",
  "img/general/borobudur.jpg",
  "img/general/komodo.png",
  "img/general/monas.jpg",
  "img/bawah-laut/raja-ampat.png",
  "img/bawah-laut/bunaken.png",
  "img/bawah-laut/banda.jpg",
  "img/gunung/puncak-jaya.png",
  "img/gunung/rinjani.png",
  "img/gunung/semeru.png",
  "img/pantai/kuta.png",
  "img/pantai/parangtritis.png",
  "img/pantai/sanur.png"
];

let addCache = (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(urlsToCache);
    })
  );
}

let fetchCache = (event) => {
  event.respondWith(
    caches
      .match(event.request, { cacheName: CACHE_NAME })
      .then((response) => {
        if (response) {
          console.log("ServiceWorker: Gunakan aset dari cache: ", response.url);
          return response;
        }
 
        console.log(
          "ServiceWorker: Memuat aset dari server: ",
          event.request.url
        );
        return fetch(event.request);
      })
  );
}

let replaceCache = (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName != CACHE_NAME) {
            console.log(`ServiceWorker: cache  ${cacheName} dihapus`);
            return caches.delete(cacheName);
          }
        })
      );
    })
  );
}


self.addEventListener("install", (event) => { addCache(event) });
self.addEventListener("fetch", (event) => { fetchCache(event) });
self.addEventListener("activate", (event) => { replaceCache(event) });